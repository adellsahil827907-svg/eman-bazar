# EMAN BAZAR v0.7

Global Buy • Sell • Connect marketplace.

## Included
- Flutter Android project structure
- Firebase Core + Authentication + Firestore
- Email/password registration and login
- Firestore listings stream and publishing
- Search/listing UI
- Sell listing form with up to 10 selected images
- Three UI languages: English, Pashto, Dari
- RTL for Pashto/Dari and LTR for English
- Chat repository foundation
- Firebase Storage upload code

## Firebase status
The project includes `android/app/google-services.json` for the registered Android app.
Firestore is ready. In the current Firebase project, Cloud Storage requires the Blaze billing plan, so image upload will only work after Storage is enabled. Publishing a listing without images does not require Storage.

## Build
This archive is source code. It needs a Flutter SDK/build environment. On a machine or cloud build environment:
1. Set `flutter.sdk` in `android/local.properties`.
2. Run `flutter pub get`.
3. Run `flutter build apk --release`.

The ZIP does not contain a prebuilt APK.
