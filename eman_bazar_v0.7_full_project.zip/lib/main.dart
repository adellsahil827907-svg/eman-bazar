import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'auth_repository.dart';
import 'chat_repository.dart';
import 'listings_repository.dart';
import 'storage_service.dart';

const gold = Color(0xFFD4AF37);
const black = Color(0xFF111111);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const EmanBazarApp());
}

class EmanBazarApp extends StatefulWidget {
  const EmanBazarApp({super.key});
  @override State<EmanBazarApp> createState() => _EmanBazarAppState();
}

class _EmanBazarAppState extends State<EmanBazarApp> {
  String lang = 'en';
  void setLang(String value) => setState(() => lang = value);

  @override
  Widget build(BuildContext context) {
    final rtl = lang != 'en';
    return Directionality(
      textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'EMAN BAZAR',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: gold),
          scaffoldBackgroundColor: Colors.white,
          appBarTheme: const AppBarTheme(backgroundColor: black, foregroundColor: Colors.white),
          inputDecorationTheme: InputDecorationTheme(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        home: AuthGate(lang: lang, onLanguage: setLang),
      ),
    );
  }
}

class T {
  static const m = {
    'en': {'home':'Home','search':'Search','sell':'Sell','chat':'Chat','profile':'Profile','categories':'Categories','new':'New Listings','login':'Login','register':'Create account','email':'Email','password':'Password','signout':'Sign out','title':'Title','description':'Description','price':'Price','country':'Country','city':'City','publish':'Publish listing','condition':'Condition','used':'Used','newItem':'New','noListings':'No listings yet','language':'Language','save':'Save'},
    'ps': {'home':'کور','search':'لټون','sell':'خرڅول','chat':'چټ','profile':'پروفایل','categories':'کټګورۍ','new':'نوي اعلانونه','login':'ننوتل','register':'حساب جوړول','email':'ایمیل','password':'پټنوم','signout':'وتل','title':'نوم','description':'تشریح','price':'بیه','country':'هیواد','city':'ښار','publish':'اعلان خپرول','condition':'حالت','used':'کارول شوی','newItem':'نوی','noListings':'تر اوسه اعلان نشته','language':'ژبه','save':'خوندي کول'},
    'fa': {'home':'خانه','search':'جستجو','sell':'فروش','chat':'چت','profile':'پروفایل','categories':'دسته‌بندی‌ها','new':'آگهی‌های جدید','login':'ورود','register':'ساخت حساب','email':'ایمیل','password':'رمز عبور','signout':'خروج','title':'نام','description':'توضیحات','price':'قیمت','country':'کشور','city':'شهر','publish':'انتشار آگهی','condition':'وضعیت','used':'دست دوم','newItem':'نو','noListings':'هنوز آگهی وجود ندارد','language':'زبان','save':'ذخیره'},
  };
  static String x(String l, String k) => m[l]?[k] ?? m['en']![k]!;
}

class AuthGate extends StatelessWidget {
  final String lang; final ValueChanged<String> onLanguage;
  const AuthGate({super.key, required this.lang, required this.onLanguage});
  @override Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: AuthRepository().authStateChanges,
    builder: (_, snap) => snap.data == null
      ? LoginPage(lang: lang, onLanguage: onLanguage)
      : HomePage(lang: lang, onLanguage: onLanguage),
  );
}

class LoginPage extends StatefulWidget {
  final String lang; final ValueChanged<String> onLanguage;
  const LoginPage({super.key, required this.lang, required this.onLanguage});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(), password = TextEditingController();
  bool register = false, busy = false;
  String? error;
  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.length < 6) {
      setState(() => error = 'Email and password (6+ characters) are required.');
      return;
    }
    setState(() {busy=true; error=null;});
    try {
      if (register) await AuthRepository().register(email.text, password.text);
      else await AuthRepository().signIn(email.text, password.text);
    } on FirebaseAuthException catch(e) {
      setState(() => error = e.message ?? e.code);
    } finally { if(mounted) setState(() => busy=false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: black,
    body: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Card(
        child: Padding(padding: const EdgeInsets.all(24), child: Column(
          children: [
            const Icon(Icons.shopping_bag, size: 70, color: gold),
            const SizedBox(height: 8),
            const Text('EMAN BAZAR', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const Text('Buy • Sell • Connect'),
            const SizedBox(height: 28),
            TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: InputDecoration(labelText:T.x(widget.lang,'email'))),
            const SizedBox(height: 12),
            TextField(controller: password, obscureText:true, decoration: InputDecoration(labelText:T.x(widget.lang,'password'))),
            if(error != null) Padding(padding: const EdgeInsets.only(top:10), child: Text(error!, style: const TextStyle(color: Colors.red))),
            const SizedBox(height: 18),
            SizedBox(width:double.infinity, child: FilledButton(
              onPressed: busy ? null : submit,
              child: Text(busy ? '...' : T.x(widget.lang, register ? 'register':'login')),
            )),
            TextButton(onPressed: busy ? null : () => setState(()=>register=!register),
              child: Text(register ? T.x(widget.lang,'login') : T.x(widget.lang,'register'))),
            TextButton(onPressed: ()=>showLanguage(context, widget.lang, widget.onLanguage),
              child: Text('${T.x(widget.lang,'language')}: ${widget.lang.toUpperCase()}')),
          ],
        )),
      ),
    )),
  );
}

void showLanguage(BuildContext context, String current, ValueChanged<String> set) {
  showModalBottomSheet(context: context, builder: (_) => Column(mainAxisSize: MainAxisSize.min, children: [
    for (final x in ['en','ps','fa']) ListTile(title: Text(x=='en'?'English':x=='ps'?'پښتو':'دری'), trailing: x==current?const Icon(Icons.check,color:gold):null, onTap:(){set(x);Navigator.pop(context);}),
  ]));
}

class HomePage extends StatefulWidget {
  final String lang; final ValueChanged<String> onLanguage;
  const HomePage({super.key, required this.lang, required this.onLanguage});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  int index=0;
  @override Widget build(BuildContext context) {
    final pages = [
      HomeTab(lang:widget.lang),
      SearchTab(lang:widget.lang),
      SellPage(lang:widget.lang),
      ChatTab(lang:widget.lang),
      ProfileTab(lang:widget.lang, onLanguage:widget.onLanguage),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('EMAN BAZAR'), actions:[IconButton(onPressed:()=>showLanguage(context,widget.lang,widget.onLanguage),icon:const Icon(Icons.language))]),
      body: pages[index],
      bottomNavigationBar: NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:[
        NavigationDestination(icon:const Icon(Icons.home_outlined),selectedIcon:const Icon(Icons.home),label:T.x(widget.lang,'home')),
        NavigationDestination(icon:const Icon(Icons.search),label:T.x(widget.lang,'search')),
        NavigationDestination(icon:const Icon(Icons.add_circle_outline),label:T.x(widget.lang,'sell')),
        NavigationDestination(icon:const Icon(Icons.chat_bubble_outline),label:T.x(widget.lang,'chat')),
        NavigationDestination(icon:const Icon(Icons.person_outline),label:T.x(widget.lang,'profile')),
      ]),
    );
  }
}

class HomeTab extends StatelessWidget {
  final String lang; const HomeTab({super.key,required this.lang});
  final cats = const ['🚗 Vehicles','📱 Phones','🏠 Property','💻 Electronics','🪑 Furniture','👕 Fashion','🔧 Tools','📦 Other'];
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    TextField(decoration:InputDecoration(hintText:'Search / لټون / جستجو',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.grey.shade100)),
    const SizedBox(height:20),Text(T.x(lang,'categories'),style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:cats.map((c)=>ActionChip(label:Text(c),onPressed:(){})).toList()),
    const SizedBox(height:24),Text(T.x(lang,'new'),style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    const SizedBox(height:10),const ListingsStream(),
  ]);
}

class ListingsStream extends StatelessWidget {
  const ListingsStream({super.key});
  @override Widget build(BuildContext context)=>StreamBuilder<List<Listing>>(
    stream:ListingsRepository().watchListings(),
    builder:(context,snap){
      if(snap.hasError) return Text('Could not load listings: ${snap.error}');
      if(snap.connectionState==ConnectionState.waiting) return const Center(child:CircularProgressIndicator());
      final list=snap.data??[];
      if(list.isEmpty) return const Padding(padding:EdgeInsets.all(30),child:Center(child:Text('No listings yet')));
      return Column(children:list.map((x)=>Card(child:ListTile(
        leading: x.imageUrls.isEmpty ? const Icon(Icons.image_outlined,size:40) : Image.network(x.imageUrls.first,width:55,height:55,fit:BoxFit.cover),
        title:Text(x.title),subtitle:Text('${x.city} • ${x.condition}'),trailing:Text('${x.price.toStringAsFixed(0)}'),
      ))).toList());
    });
}

class SearchTab extends StatelessWidget {
  final String lang; const SearchTab({super.key,required this.lang});
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(16),child:Column(children:[
    TextField(decoration:InputDecoration(labelText:T.x(lang,'search'),prefixIcon:const Icon(Icons.search))),
    const SizedBox(height:16), const Expanded(child:ListingsStream()),
  ]));
}

class SellPage extends StatefulWidget {
  final String lang; const SellPage({super.key,required this.lang});
  @override State<SellPage> createState()=>_SellPageState();
}
class _SellPageState extends State<SellPage> {
  final title=TextEditingController(),desc=TextEditingController(),price=TextEditingController(),country=TextEditingController(),city=TextEditingController();
  String category='Other', condition='Used'; bool busy=false; List<XFile> images=[];
  final picker=ImagePicker();
  Future<void> pick() async { final xs=await picker.pickMultiImage(limit:10); setState(()=>images=xs); }
  Future<void> publish() async {
    final u=FirebaseAuth.instance.currentUser;
    if(u==null || title.text.trim().isEmpty || price.text.trim().isEmpty) return;
    setState(()=>busy=true);
    try {
      final tempId=DateTime.now().millisecondsSinceEpoch.toString();
      final urls=<String>[];
      // Storage requires Blaze in the current Firebase project; keep publishing usable with no images.
      if(images.isNotEmpty) {
        for(final x in images) urls.add(await StorageService().uploadListingImage(x.path,tempId));
      }
      await ListingsRepository().createListing(Listing(id:tempId,title:title.text.trim(),description:desc.text.trim(),price:double.tryParse(price.text) ?? 0,country:country.text.trim(),city:city.text.trim(),category:category,condition:condition,userId:u.uid,imageUrls:urls));
      if(mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Listing published'))); Navigator.pop(context); }
    } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e'))); }
    finally { if(mounted) setState(()=>busy=false); }
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    Text(T.x(widget.lang,'title')), TextField(controller:title),
    const SizedBox(height:10),Text(T.x(widget.lang,'description')),TextField(controller:desc,maxLines:4),
    const SizedBox(height:10),Text(T.x(widget.lang,'price')),TextField(controller:price,keyboardType:TextInputType.number),
    const SizedBox(height:10),Text(T.x(widget.lang,'country')),TextField(controller:country),
    const SizedBox(height:10),Text(T.x(widget.lang,'city')),TextField(controller:city),
    const SizedBox(height:10),DropdownButtonFormField(value:category,items:['Vehicles','Phones','Property','Electronics','Furniture','Fashion','Tools','Other'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>category=v!)),
    const SizedBox(height:10),DropdownButtonFormField(value:condition,items:['Used','New'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>condition=v!)),
    const SizedBox(height:10),OutlinedButton.icon(onPressed:pick,icon:const Icon(Icons.photo_library),label:Text('Photos: ${images.length}/10')),
    const SizedBox(height:18),SizedBox(height:50,child:FilledButton(onPressed:busy?null:publish,child:Text(busy?'...':T.x(widget.lang,'publish')))),
  ]);
}

class ChatTab extends StatelessWidget {
  final String lang; const ChatTab({super.key,required this.lang});
  @override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(24),child:Text('${T.x(lang,"chat")}\n\nStart a conversation from a listing.',textAlign:TextAlign.center)));
}

class ProfileTab extends StatelessWidget {
  final String lang; final ValueChanged<String> onLanguage;
  const ProfileTab({super.key,required this.lang,required this.onLanguage});
  @override Widget build(BuildContext context){ final u=FirebaseAuth.instance.currentUser; return ListView(padding:const EdgeInsets.all(16),children:[
    const CircleAvatar(radius:42,child:Icon(Icons.person,size:45)),const SizedBox(height:12),
    Center(child:Text(u?.email??'',style:const TextStyle(fontWeight:FontWeight.bold))),
    const SizedBox(height:20),
    ListTile(leading:const Icon(Icons.language),title:Text(T.x(lang,'language')),trailing:Text(lang.toUpperCase()),onTap:()=>showLanguage(context,lang,onLanguage)),
    ListTile(leading:const Icon(Icons.logout),title:Text(T.x(lang,'signout')),onTap:()=>AuthRepository().signOut()),
  ]);}
}
