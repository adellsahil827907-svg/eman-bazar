import 'package:cloud_firestore/cloud_firestore.dart';

class ChatRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<Map<String, dynamic>>> messages(String conversationId) =>
      _db.collection('chats').doc(conversationId).collection('messages')
        .orderBy('createdAt')
        .snapshots()
        .map((s) => s.docs.map((d) => {'id': d.id, ...d.data()}).toList());

  Future<void> sendMessage(String conversationId, String senderId, String text) =>
      _db.collection('chats').doc(conversationId).collection('messages').add({
        'senderId': senderId,
        'text': text.trim(),
        'createdAt': FieldValue.serverTimestamp(),
      });
}
