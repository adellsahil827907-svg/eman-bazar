import 'package:cloud_firestore/cloud_firestore.dart';

class Listing {
  final String id;
  final String title;
  final String description;
  final double price;
  final String country;
  final String city;
  final String category;
  final String condition;
  final String userId;
  final List<String> imageUrls;
  final DateTime? createdAt;

  const Listing({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.country,
    required this.city,
    required this.category,
    required this.condition,
    required this.userId,
    required this.imageUrls,
    this.createdAt,
  });

  factory Listing.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    return Listing(
      id: doc.id,
      title: d['title'] as String? ?? '',
      description: d['description'] as String? ?? '',
      price: (d['price'] as num?)?.toDouble() ?? 0,
      country: d['country'] as String? ?? '',
      city: d['city'] as String? ?? '',
      category: d['category'] as String? ?? 'Other',
      condition: d['condition'] as String? ?? 'Used',
      userId: d['userId'] as String? ?? '',
      imageUrls: List<String>.from(d['imageUrls'] ?? const []),
      createdAt: (d['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() => {
    'title': title,
    'description': description,
    'price': price,
    'country': country,
    'city': city,
    'category': category,
    'condition': condition,
    'userId': userId,
    'imageUrls': imageUrls,
    'createdAt': FieldValue.serverTimestamp(),
  };
}

class ListingsRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<Listing>> watchListings() => _db
      .collection('listings')
      .orderBy('createdAt', descending: true)
      .limit(50)
      .snapshots()
      .map((s) => s.docs.map(Listing.fromDoc).toList());

  Future<String> createListing(Listing listing) async {
    final ref = await _db.collection('listings').add(listing.toMap());
    return ref.id;
  }

  Future<void> deleteListing(String id) =>
      _db.collection('listings').doc(id).delete();
}
