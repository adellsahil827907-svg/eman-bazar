import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<String> uploadListingImage(String localPath, String listingId) async {
    final file = File(localPath);
    final name = '${DateTime.now().millisecondsSinceEpoch}_${file.uri.pathSegments.last}';
    final ref = _storage.ref('listings/$listingId/$name');
    await ref.putFile(file);
    return ref.getDownloadURL();
  }
}
