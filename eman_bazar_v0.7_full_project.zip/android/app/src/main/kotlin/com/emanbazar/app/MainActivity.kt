package com.emanbazar.app
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
